import java.io.File;  // Import the File class
	import java.io.IOException; 
public class createFile {
public static void main(String[] args) {
	 // Import the IOException class to handle errors

	
	    try {
	      File newfile = new File("a.txt");
	      File newfile2 = new File("b.txt");
	      newfile2.createNewFile();
	      if (newfile.createNewFile()) {
	        System.out.println("File created: " + newfile.getName());
	      } else {
	        System.out.println("File already exists.");
	      }
	    } catch (IOException e) {
	      System.out.println("An error occurred.");
	      e.printStackTrace();
	    }
	  }
	
}

