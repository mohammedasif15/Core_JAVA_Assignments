interface MediceneInfo{
	public void displayLabel();
}
class Tablet implements MediceneInfo{

	@Override
	public void displayLabel() {
		System.out.println("Store tablets in cool and dry place");
		
	}
	
}
class Syrup implements MediceneInfo{

	@Override
	public void displayLabel() {
		System.out.println("Consult Doctor Before using");
	}
	
}
class Ontientment implements MediceneInfo{

	@Override
	public void displayLabel() {
		System.out.println("for external use only");
		
	}
	
}
public class Medicene {
	public static void main(String[] args) {
		MediceneInfo mt=new Tablet();
		MediceneInfo ms=new Syrup();
		MediceneInfo mo =new Ontientment();
		mt.displayLabel();
		ms.displayLabel();
		mo.displayLabel();
	}

}
