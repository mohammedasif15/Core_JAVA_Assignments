
public class StringEx {
public static void main(String[] args) {
	System.out.println(args[0]);
   System.out.println(args[0].toUpperCase());
   String name=args[0];
   String rev="";
   int l=name.length();
   System.out.println(l);
   for(int i=l-1;i>=0;i--) {
	   rev=rev+name.charAt(i);
   }
   System.out.println(rev);
   if(name.equals(rev)) {
	   System.out.println("Palindrome");
   }
   else {
	   System.out.println("Not palindrome");
   }
}
}
