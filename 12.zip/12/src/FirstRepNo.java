import java.util.*;
public class FirstRepNo {
	

	
	
		static void RepeatedElement(int m[])
		{
			
			int min = -1;

			
			HashSet<Integer> set = new HashSet<>();

			
			for (int i=m.length-1; i>=0; i--)
			{
				
				if (set.contains(m[i]))
					min = i;

				else
					set.add(m[i]);
			}

			if (min != -1)
			System.out.println("First repeated element in array is " + m[min]);
			else
			System.out.println("No Eleemts Are Repeated");
		}

		public static void main (String[] args) throws java.lang.Exception
		{
			int arr[] = {1, 2, 3, 10, 2, 4, 5, 7, 8 };
			RepeatedElement(arr);
		}
	}

