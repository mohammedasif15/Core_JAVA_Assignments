import java.util.*;

public class BracketsCheck {
	    static boolean isBracketsBalanced(String expr)
	    {
	        Deque<Character> balance
	            = new ArrayDeque<Character>();
	 
	        for (int i = 0; i < expr.length(); i++)
	        {
	            char x = expr.charAt(i);
	 
	            if (x == '(' || x == '[' || x == '{')
	            {
	            	balance.push(x);
	                continue;
	            }
	 
	            if (balance.isEmpty())
	                return false;
	            char check;
	            switch (x) {
	            case ')':
	                check = balance.pop();
	                if (check == '{' || check == '[')
	                    return false;
	                break;
	 
	            case '}':
	                check = balance.pop();
	                if (check == '(' || check == '[')
	                    return false;
	                break;
	 
	            case ']':
	                check = balance.pop();
	                if (check == '(' || check == '{')
	                    return false;
	                break;
	            }
	        }
	        return (balance.isEmpty());
	    }
	    public static void main(String[] args)
	    {
	        String brack = "[()]{}{[()()]()}";
	 
	        if (isBracketsBalanced(brack))
	            System.out.println("Balanced ");
	        else
	            System.out.println("Not Balanced ");
	    }
	}

