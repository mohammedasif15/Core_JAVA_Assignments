
public class Manipulate {
public static void main(String[] args) {
	String s="JAVA is Simple";
	System.out.println(s.toUpperCase());
	System.out.println(s.toLowerCase());
	System.out.println(s.charAt(0)+" "+s.charAt(5)+" "+s.charAt(8));
	String[] ss= s.split(" ");
	
	for(int i = ss.length-1; i >= 0; i--) {
		System.out.print(ss[i]+" ");
	}
	StringBuffer sm = new StringBuffer(s);
	s= sm.reverse().toString();
	String[] rev = s.split(" ");
	StringBuffer reverse = new StringBuffer();
	for(int i = rev.length - 1; i >= 0; i--)
		reverse.append(rev[i]).append(" ");
	
	System.out.println(reverse.toString());
	System.out.println(s.length());
}

}
