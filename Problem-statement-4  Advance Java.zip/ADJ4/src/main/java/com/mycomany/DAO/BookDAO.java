package com.mycomany.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mycompany.DBUtil.DBConnection;

public class BookDAO {
  public static ResultSet display() throws ClassNotFoundException, SQLException {
	  String sql="select * from Books";
	  Connection con=DBConnection.Dbcon();
	 PreparedStatement ps=con.prepareStatement(sql);
	 return ps.executeQuery();
	  
  }
}
