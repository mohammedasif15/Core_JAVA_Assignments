import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileRead {
public static void main(String[] args) throws IOException  {
	FileReader fr=new FileReader("I://springEclipse//springtool-workspace//7.2//a.txt");
	System.out.println(fr.read());
}
}
