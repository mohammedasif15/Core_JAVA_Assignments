import java.util.*;
public class RepeatingDecimal {
	
	    static StringBuffer result=new StringBuffer();

		public static String calculateRepeatingDecimal(int numeator, int denominator)
		{
			if (numeator == 0)
			if (denominator == 0)
			if ((numeator < 0) ^ (denominator < 0))
				result.append("-");	
	
			numeator = Math.abs(numeator);
			denominator = Math.abs(denominator);
			long quotent = numeator / denominator; 
			long remainder = numeator % denominator * 10; 
			result.append(
				String.valueOf(quotent)); 
			if (remainder == 0)
				return result
					.toString(); 
			result.append(".");
			Map<Long, Integer> m
				= new HashMap<>();
			while (remainder != 0) {
				if (m.containsKey(remainder)) {

					int index = m.get(remainder);
					String part1 = result.substring(0, index);
					String part2 = "("
								+ result.substring(
									index, result.length())
								+ ")";
					return part1 + part2;
				}
				m.put(remainder, result.length());
				quotent = remainder / denominator;
				result.append(String.valueOf(quotent));

				remainder = (remainder % denominator) * 10;
			}
			return result.toString();
		}		
		public static void main(String[] args)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter Numerator");
			int numerator = sc.nextInt();
			System.out.println("Enter Denominator");
			int denominator = sc.nextInt();

			String cal = calculateRepeatingDecimal(numerator, denominator);
			System.out.println("the repeating sequence is : "+cal);
			
		}
	}

