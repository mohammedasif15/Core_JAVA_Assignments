import java.util.Scanner;

class climbingStep {
    static int fib(int a)
    {
        if (a <= 1)
            return a;
        return fib(a - 1) + fib(a - 2);
    }
 
    static int NoStep(int s)
    {
        return fib(s + 1);
    }
 
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the steps");
        int m=sc.nextInt();
       
        System.out.println("Number of ways = " + NoStep(m));
    }
}