
public class TestRectangle {
public static void main(String[] args) {
	Rectangle r1=new Rectangle(2, 8);
	Rectangle r2=new Rectangle(8, 9);
	Rectangle r3=new Rectangle(12, 18);
	Rectangle r4=new Rectangle(21,44);
	Rectangle r5=new Rectangle(9, 55);
}
}
