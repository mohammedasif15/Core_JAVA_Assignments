
public class Rectangle {
 
	int len=0,bre=0;
	Rectangle(int len,int bre){
		this.len=len;
		this.bre=bre;
		int a=len*bre;
		System.out.println(a);
	}
	
}
