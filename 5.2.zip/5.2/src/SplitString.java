
public class SplitString {
public static void main(String[] args) {
	String[] seperate=new String[]{};
	String s="23 + 45 - ( 343 / 12 )";

	String[] res=s.split(" ");
	for(String u:res) {
		System.out.println(u);
	}
}
}
