import java.util.Arrays;
import java.util.LinkedList;
import java.util.Scanner;

class Employee_Details{
	LinkedList<Employee_Details> list =new LinkedList<>();
	int id;
	String name;
	String add;
	public Employee_Details(int id, String name, String add) {
		super();
		this.id = id;
		this.name = name;
	this.add =add;
	}
	
	public void addInput() {
		
		int id;String name,add;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter Employee Details...");
		System.out.println("Enter id");
		id=sc.nextInt();
		System.out.println("enter name");
		name=sc.next();
		System.out.println("Enter Address");
		add=sc.next();
		Employee_Details emp1=new Employee_Details(id, name, add);
	
		list.add(emp1);
	}
	public void display() {
		for(Employee_Details e:list) {
			System.out.println(e.id+" "+e.name+" "+e.add);
		}
	}
}

	
	
	

public class Employee {
public static void main(String[] args) {
	Employee_Details emp=new Employee_Details(1, "Asif", "Banglore");
	emp.list.add(emp);
	emp.addInput();
	emp.display();

	
}
}
