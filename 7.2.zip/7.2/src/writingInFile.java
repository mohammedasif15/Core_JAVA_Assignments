	import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
	
import java.util.Scanner;
public class writingInFile {
     public static void main(String[] args) throws IOException
	    {
    	 Scanner sc=new Scanner(System.in);
    	 
//         File f1=new File("a.txt");
//         f1.createNewFile();
        System.out.println("enter the Rollno");
        String roll=sc.next();
        System.out.println("Enter the age");
        String age=sc.next();
        String text="Roll number is "+roll+" age is"+age;
        FileWriter fWriter = new FileWriter(
                "I:/springEclipse/springtool-workspace/7.2/a.txt");
 
        fWriter.write(text);
 System.out.println("Successfully Writen in file");

	    }
	}

