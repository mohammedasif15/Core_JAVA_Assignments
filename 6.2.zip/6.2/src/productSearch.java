import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

public class productSearch {

	public static void main(String[] args) {
		HashMap<Integer, String> hs=new HashMap<>();
		hs.put(001, "Maruti 800");
		hs.put(002, "Swift");
		hs.put(003, "Zen");
		hs.put(004, "Alto");
		hs.put(005, "Skoda");
		System.out.println(hs);
	System.out.println("Enter the key to search");
	Scanner sc=new Scanner(System.in);
	int id=sc.nextInt();
	if(hs.containsKey(id)) {
		System.out.println("Product is present");
	}
	else {
		System.out.println("Product is not present");
	}
		System.out.println("Enter the product id to delete");
		int d=sc.nextInt();
	     hs.remove(d);
	     System.out.println(hs);
		}
	}
	
	

