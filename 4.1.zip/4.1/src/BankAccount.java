 class BankAccount {
int accNo;
String custName;
public BankAccount(int accNo, String custName, String accType, float balance) {
	super();
	this.accNo = accNo;
	this.custName = custName;
	this.accType = accType;
	this.balance = balance;
}
String accType;
float balance;
public void deposit(float amt) {
	if(amt<0) {
		System.out.println("Negative balance exeption");
	}
balance=balance+amt;
System.out.println(getBalance());
}
public void withdraw(float amt) {
	balance=balance-amt;
	if(balance<1000) {
		System.out.println("balance is low");
	}
	System.out.println(getBalance());
}
public float getBalance() {
	return balance;
}
public static void main(String[] args) {
	BankAccount b=new BankAccount(12345,"Asif", "savings", 1000);
//	b.deposit(1000);
b.withdraw(100);
	b.getBalance();
}
}
