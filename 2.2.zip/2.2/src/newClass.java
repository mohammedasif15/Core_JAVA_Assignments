
public class newClass {
public static void main(String[] args) {
	System.out.println(args[0]+" "+args[1]);
	int n1=Integer.parseInt(args[0]);
	int n2=Integer.parseInt(args[1]);
	int sum=0,sumto;
	for(int i=0;i<=13;i++) {
		sum=n1+n2;
		sumto=sum+n2;
		n1=n2;
		n2=sum;
		
		System.out.println(sumto);
	}

}
}
