package com.mycomany.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.mycompany.Bean.Order_Details;

import com.mycompany.DBUtil.DBConnection;

public class OrderDAO {
	public static int insert(Order_Details o) throws ClassNotFoundException, SQLException {
		String sql="insert into Order_Details(book_Id,Cust_Name,Phone_No,Address,Order_Date,Quantity) values(?,?,?,?,?,?)";
		Connection con=DBConnection.Dbcon();
        PreparedStatement ps=con.prepareStatement(sql);
        ps.setInt(1,o.getBook_ID());
        ps.setString(2,o.getCustomer_Name());
        ps.setLong(3,o.getPhone());
        ps.setString(4,o.getAddress());
        ps.setString(5,java.time.LocalDate.now().toString());
        ps.setInt(6,o.getQuantity());
        return ps.executeUpdate();
	}
}
