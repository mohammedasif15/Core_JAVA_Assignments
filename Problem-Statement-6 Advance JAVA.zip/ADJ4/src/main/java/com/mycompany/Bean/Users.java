package com.mycompany.Bean;

public class Users {
 String First_Name;
 String Address;
 String Email;
 String User_Name;
 String Password;
public String getFirst_Name() {
	return First_Name;
}
public void setFirst_Name(String first_Name) {
	First_Name = first_Name;
}
public String getAddress() {
	return Address;
}
public void setAddress(String address) {
	Address = address;
}
public String getEmail() {
	return Email;
}
public void setEmail(String email) {
	Email = email;
}
public String getUser_Name() {
	return User_Name;
}
public void setUser_Name(String user_Name) {
	User_Name = user_Name;
}
public String getPassword() {
	return Password;
}
public void setPassword(String password) {
	Password = password;
}
}
