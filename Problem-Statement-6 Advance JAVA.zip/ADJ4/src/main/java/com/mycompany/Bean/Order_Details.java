package com.mycompany.Bean;

public class Order_Details {
int OrderID;
int Book_ID;
String Customer_Name;
String Address;
long phone;
int quantity;
public int getOrderID() {
	return OrderID;
}
public void setOrderID(int orderID) {
	OrderID = orderID;
}
public int getBook_ID() {
	return Book_ID;
}
public void setBook_ID(int book_ID) {
	Book_ID = book_ID;
}
public String getCustomer_Name() {
	return Customer_Name;
}
public void setCustomer_Name(String customer_Name) {
	Customer_Name = customer_Name;
}
public String getAddress() {
	return Address;
}
public void setAddress(String address) {
	Address = address;
}
public long getPhone() {
	return phone;
}
public void setPhone(long phone) {
	this.phone = phone;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
}
