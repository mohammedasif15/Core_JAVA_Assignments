package com.mycompany.app;

import java.sql.SQLException;
import java.util.Scanner;

import com.mycompany.dao.ProductManagementDAO;
import com.mycompany.domain.Product;

public class ProductManagementApp {
public static void main(String[] args) throws ClassNotFoundException, SQLException {
	Scanner sc=new Scanner(System.in);
	Product p=new Product();
	ProductManagementDAO pd=new ProductManagementDAO();
	int g;
	System.out.println("******WELCOME TO THE SHOP**********");
	System.out.println();
	
try {
	
	while (true) {
		System.out.println("1.Add Product\n2.Search Product\n3.Update Product\n4.Display Products\n5.Delete Product\n6.Exit");
		System.out.println("******************");
		System.out.println("Enter An Option");
		System.out.println("******************");
		g=sc.nextInt();
		switch(g) {
		case 1:{
			System.out.println("Enter Product id");
			p.setId(sc.nextInt());
			System.out.println("Enter Product name");
			p.setName(sc.next());
			System.out.println("Enter Price");
			p.setPrice(sc.nextInt());
			
			int m=pd.insert(p);
			if(m>0) {
				System.out.println("insertion successfull");
			}
			else {
				System.out.println("insertion faild");
			}
			break;
		}
		case 2:{
			
			System.out.println("Enter Product Id");
			p.setId(sc.nextInt());
			pd.search(p);
			break;
		}
		case 3:{
			System.out.println("Enter Product Name");
			p.setName(sc.next());
			System.out.println("Enter Product Price");
			p.setPrice(sc.nextInt());
			System.out.println("Enter Product ID");
			p.setId(sc.nextInt());
			int s=pd.update(p);
			if(s>0) {
				System.out.println("updated successfully");
			}
			else {
				System.out.println("not Updated");
			}
			break;
		}
		case 4:{
			
			pd.display();
			break;
			
		}
		case 5:{
			System.out.println("Enter Product id");
			p.setId(sc.nextInt());
			int q=pd.delete(p);
		    if(q>0)
		            {		
			         System.out.println("Deleted Sucessfully");
		           }

		      else 
		        {		
			       System.out.println("deletion failed");

		         }
			break;
		}
		case 6:
			System.out.println("******************Thank You**************************************");
			System.exit(0);
		
		}
		
	
	}
}catch(Exception e) {
	e.printStackTrace();
}
	
}
}
