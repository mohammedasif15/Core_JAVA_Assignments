package com.mycompany.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mycompany.dbutil.DBUtil;
import com.mycompany.domain.Product;

public class ProductManagementDAO {
	
	public static int insert(Product p) throws ClassNotFoundException, SQLException {
		String sql="insert into product values (?,?,?)";
		Connection con=DBUtil.DbConnection();
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1, p.getId());
		ps.setString(2, p.getName());
		ps.setInt(3, p.getPrice());
		return ps.executeUpdate();
	}
	public static void display() throws ClassNotFoundException, SQLException {
		String sql="select * from product";
		Connection con=DBUtil.DbConnection();
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs= ps.executeQuery();
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3));
		}
	}
	public static int update(Product p) throws ClassNotFoundException, SQLException {
		String sql="update product set productname=?,price=? where ProductId=?";
		Connection con=DBUtil.DbConnection();
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, p.getName());
		ps.setInt(2, p.getPrice());
		ps.setInt(3, p.getId());
		return ps.executeUpdate();
	}
	public static void search(Product p) throws ClassNotFoundException, SQLException {
		String sql="select * from product where ProductId=?";
		Connection con=DBUtil.DbConnection();
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1,p.getId() );
		ResultSet rs= ps.executeQuery();
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3));
		}
	}
	public static int delete(Product p) throws ClassNotFoundException, SQLException {
		String sql="delete from product where ProductId=?";
		Connection con=DBUtil.DbConnection();
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1, p.getId());
		return ps.executeUpdate();
	}
}
