


 
class Cal_freq {
     
    static int frequency(int a[],
    int n, int x)
    {
        int count = 0;
        for (int i=0; i < n; i++)
        if (a[i] == x)
            count++;
        return count;
    }
     
 
    public static void main (String[] args) {
         
        int a[] = {2, 2, 2, 4, 4, 4, 5, 5, 6, 8, 8, 9};
        int x = 5,y=2,z=4,c=6,m=8,i=9;
        
        int n = a.length;
         
        System.out.println("Frequency of 5 :"+frequency(a, n, x));
        System.out.println("Frequency of 2 :"+frequency(a, n, y));
        System.out.println("Frequency of 4 :"+frequency(a, n, z));
        System.out.println("Frequency of 6 :"+frequency(a, n, c));
        System.out.println("Frequency of 8 :"+frequency(a, n, m));
        System.out.println("Frequency of 9 :"+frequency(a, n, i));
    }
}

