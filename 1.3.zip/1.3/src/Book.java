
 class Book_Des {
	private String book_title;
	 private int book_price;
 public String getBook_title() {
		return book_title;
	}
	public void setBook_title(String book_title) {
		this.book_title = book_title;
	}
	public int getBook_price() {
		return book_price;
	}
	public void setBook_price(int book_price) {
		this.book_price = book_price;
	}
	@Override
	public String toString() {
		return "Book_Des [book_title=" + book_title + ", book_price=" + book_price + ", getBook_title()="
				+ getBook_title() + ", getBook_price()=" + getBook_price() + "]";
	}

 
}
public class Book{
	public static void main(String[] args) {
		Book_Des b=new Book_Des();
		b.setBook_title("java Programing");
		b.setBook_price(200);
		System.out.println(b.toString());
		
	}
}