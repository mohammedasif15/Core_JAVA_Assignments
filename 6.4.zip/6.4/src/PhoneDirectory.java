import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class PhoneDirectory {
public static void main(String[] args) {
	HashMap<String, Integer> hs =new HashMap<String, Integer>();
	Scanner sc=new Scanner(System.in);
	hs.put("Asif", 123456778);
	hs.put("David", 123456778);
	hs.put("jhon", 123456778);
	hs.put("Harry", 123456778);
	hs.put("Lone", 123456778);
	
	while(true) {
		System.out.println("What action u want to Perform\n1.Search Phone Number\n2.Add Phone Number\n3.Quit");
		int i=sc.nextInt();
	
		switch(i) {
		case 1:{
			System.out.println("Ener the name to search");
			String name=sc.next();
			if(hs.containsKey(name)) {
				System.out.println("Phone Number is"+hs.get(name));
				break;
			}
			else {
				System.out.println("not Present");
				break;
			}
		}
		
			case 2:{

				System.out.println("Enter the name");
				String n=sc.next();
				System.out.println("Enter the mobile number");
				int phone=sc.nextInt();
				hs.put(n, phone);
				System.out.println("Entry Added");
				System.out.println(hs);
				break;
			}
			
			case 3:System.exit(0);
		}
		}
	

	

	
	}	

}
