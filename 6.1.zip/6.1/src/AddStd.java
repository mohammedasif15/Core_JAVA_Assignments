import java.util.ArrayList;
import java.util.Scanner;

public class AddStd {
public static void main(String[] args) {
	ArrayList<String> al=new ArrayList<>();	
	al.add("Asif");
	al.add("Tariq");
	al.add("Shaqib");
	al.add("Shoiab");
	al.add("Siddque");
	System.out.println("enter the name u want to serach");
	Scanner scanner=new Scanner(System.in);
	String name=scanner.next();
	boolean se=false;
	for(String s:al) {
		if(name.equals(s)) {
		se=true;
		break;
		}
	}
	if(se==true) {
		System.out.println("name found");
	}
	else {
		System.out.println("Name not found");
	}
}
}
