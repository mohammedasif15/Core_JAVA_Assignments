
public class array {
public static void main(String[] args) {
	int A[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
	int sum=0,avg;
	for(int i=0;i<=A.length-1;i++) {
		sum=sum+A[i];
		
	}
	avg=sum%A.length;
	System.out.println(sum);
	A[15]=sum;
	A[16]=avg;
	int small=A[0];
	for(int j=0;j<=A.length-2;j++) {
		if(A[j]<small) {
			small=A[j];
		}
	}
	System.out.println(small);
	A[17]=small;
	for(int j=0;j<=A.length-1;j++) {
		System.out.println(A[j]);
		}
}
}
