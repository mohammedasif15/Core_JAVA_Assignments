package com.mycompany.Bean;

public class Books {
int id;
String Book_name;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getBook_name() {
	return Book_name;
}
public void setBook_name(String book_name) {
	Book_name = book_name;
}
public String getAuthor() {
	return Author;
}
public void setAuthor(String author) {
	Author = author;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
String Author;
int price;
}
