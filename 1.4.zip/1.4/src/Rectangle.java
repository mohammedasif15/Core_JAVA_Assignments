class AreaOfRectangle{
	
	private float length=1,width=1;

	public float getLength() {
		return length;
	}

	public void setLength(float length) {
		this.length = length;
	}

	public float  getWidth() {
		return width;
	}

	public void setWidth(float width) {
		this.width = width;
	}
	public void area() {
		float  area=length*width;
	System.out.println(area);
	}
}
public class Rectangle {
public static void main(String[] args) {
	AreaOfRectangle a=new AreaOfRectangle();
	a.setLength(2.2f);
	a.setWidth(4.2f);
	a.area();
	
}
}
